export * from './CategoriesApi';
import { CategoriesApi } from './CategoriesApi';
export * from './ProductsApi';
import { ProductsApi } from './ProductsApi';
export const APIS = [CategoriesApi, ProductsApi];
